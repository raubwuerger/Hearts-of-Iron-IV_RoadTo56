version="2025-11-23"
tags={
	"Translation"
}
name="Road to 56 - German Edition"
supported_version="1.17.0"
path="C:/Users/jha/Documents/Paradox Interactive/Hearts of Iron IV/mod/Road to 56 - German Edition"
remote_file_id="2421485863"