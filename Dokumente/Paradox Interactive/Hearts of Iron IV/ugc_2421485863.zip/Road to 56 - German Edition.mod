version="2025-06-07"
tags={
	"Translation"
}
name="Road to 56 - German Edition"
supported_version="1.16.*"
path="C:/Users/RitterDerTiefe/Documents/Paradox Interactive/Hearts of Iron IV/mod/Road to 56 - German Edition"
remote_file_id="2421485863"