﻿Translation for the mod The Road to 56 (Version 2025-06-07a)

My thanks go to the great work of The Road to 56 developers.
https://steamcommunity.com/sharedfiles/filedetails/?id=820260968&searchtext=road+to+56

History

2025-07-04 		2025-06-07a 		Focus tree of Colombia is now displayed correctly
2025-06-13		2025-06-07			Adaptation to version 2025-06-07
2025-04-13		2025-04-07			Adaptation to version 2025-04-07
2025-03-29 		2025-03-17 			Adaptation to version 2025-03-21
2025-03-06 		2025-02-07f 		Error in focus trees fixed. Many small errors in connection with line breaks have been fixed.
2025-03-02		2025-02-07e			Fixed errors in several translation files.
2025-02-26		2025-02-07d			Fixed a bug that causes the game crashing (error code: 3221225477).
2025-02-25		2025-02-07c			Removed duplicate keys from files.
2025-02-21		2025-02-07b 		All tab characters after the keys removed
2025-02-21		2025-02-07 			Adjustments to version 2025-02-07
2024-12-22		2024-12-pre01		Update to December version
2024-15-10		0.9-pre4			Corrected over 400 issues.
2024-13-10		0.9-pre3			Update to October version
2024-09-10		0.9-pre2			Update to September version
2024-08-11		0.9-pre1 			Complete new translation

Roadmap:

This translation is completely new and was created with DeepL. But since DeepL translates everything, including variables, color codes, icons, ...
there will still be a lot of translation errors. I will correct these over the next few months. With BlackICE it took about 6 months.

Notes:
If you expect untranslated texts (e.g. GER_privatise_reichsbahn, GER_war_with_spain, ...) to be displayed again, copy the content of my mod into the directory of RoadTo56.
copy .\SteamLibrary\steamapps\workshop\content\394360\2421485863\localisation to .\SteamLibrary\steamapps\workshop\content\394360\820260968\localisation.