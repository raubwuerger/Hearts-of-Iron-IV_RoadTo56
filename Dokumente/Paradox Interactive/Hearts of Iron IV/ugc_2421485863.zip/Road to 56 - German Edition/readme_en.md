﻿Translation for the mod The Road to 56 (Version 2026-06-07)

My thanks go to the great work of The Road to 56 developers.
https://steamcommunity.com/sharedfiles/filedetails/?id=820260968&searchtext=road+to+56

History
Date            Version             Description

2026-03-10		2026-06-07			Adaptation to version 2026-06-07
2026-01-19		2026-01-17			Adaptation to version 2026-01-17
2025-10-10 		2025-10-07			Adaptation to version 2025-10-07
2025-03-29		2025-03-17			Adjustments to version 2025-03-21
2024-03-06		2025-02-07e			Fixed bug in focus trees. Fixed many small bugs related to line breaks.
2024-03-02		2025-02-07e			Fixed errors in several translation files.
2024-02-26		2025-02-07d			Fixed a bug that causes the game crashing (error code: 3221225477).
2024-02-25		2025-02-07c			Removed duplicate keys from files.
2024-02-21		2025-02-07b 		All tab characters after the keys removed
2024-02-21		2025-02-07 			Adjustments to version 2025-02-07
2024-12-22		2024-12-pre01		Update to December version
2024-15-10		0.9-pre4			Corrected over 400 issues.
2024-13-10		0.9-pre3			Update to October version
2024-09-10		0.9-pre2			Update to September version
2024-08-11		0.9-pre1 			Complete new translation

Roadmap:

This translation is completely new and was created with DeepL. But since DeepL translates everything, including variables, color codes, icons, ...
there will still be a lot of translation errors. I will correct these over the next few months. With BlackICE it took about 6 months.

Notes:
If you expect untranslated texts (e.g. GER_privatise_reichsbahn, GER_war_with_spain, ...) to be displayed again, copy the content of my mod into the directory of RoadTo56.
copy .\SteamLibrary\steamapps\workshop\content\394360\2421485863\localisation to .\SteamLibrary\steamapps\workshop\content\394360\820260968\localisation.