﻿Translation for the mod The Road to 56 (Version 2025-02-07)

My thanks go to the great work of The Road to 56 developers.
https://steamcommunity.com/sharedfiles/filedetails/?id=820260968&searchtext=road+to+56

History

2024-02-26		2025-02-07d			Fixed a bug that causes the game crashing (error code: 3221225477).
2024-02-25		2025-02-07c			Removed duplicate keys from files.
2024-02-21		2025-02-07b 		All tab characters after the keys removed
2024-02-21		2025-02-07 			Adjustments to version 2025-02-07
2024-12-22		2024-12-pre01		Update to December version
2024-15-10		0.9-pre4			Corrected over 400 issues.
2024-13-10		0.9-pre3			Update to October version
2024-09-10		0.9-pre2			Update to September version
2024-08-11		0.9-pre1 			Complete new translation

Roadmap:

This translation is completely new and was created with DeepL. But since DeepL translates everything, including variables, color codes, icons, ...
there will still be a lot of translation errors. I will correct these over the next few months. With BlackICE it took about 6 months.