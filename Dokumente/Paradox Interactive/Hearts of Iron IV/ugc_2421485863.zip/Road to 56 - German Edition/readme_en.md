Translation for the mod The Road to 56 (Version August 2024)

My thanks go to the great work of The Road to 56 developers.
https://steamcommunity.com/sharedfiles/filedetails/?id=820260968&searchtext=road+to+56

History

2024-08-11		0.9-pre1 	Complete new translation

Roadmap:

This translation is completely new and was created with DeepL. But since DeepL translates everything, including variables, color codes, icons, ...
there will still be a lot of translation errors. I will correct these over the next few months. With BlackICE it took about 6 months.