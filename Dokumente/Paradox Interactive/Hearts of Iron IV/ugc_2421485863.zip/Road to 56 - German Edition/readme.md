﻿Übersetzung für die mod The Road to 56 (Version 2025-10-07)

Mein Dank geht an die tolle Arbeit der The Road to 56 Entwickler.
https://steamcommunity.com/sharedfiles/filedetails/?id=820260968&searchtext=road+to+56

History

2025-10-10		2025-10-07			Anpassung an Version 2025-10-07
2025-08-11		2025-08-07			Anpassung an Version 2025-08-07
2025-03-29		2025-03-17			Anpassung an Version 2025-03-21
2024-03-06		2025-02-07f			Fehler in Focusbäumen behoben. Viele kleine Fehler im Zusammenhang mit Zeilenumbrüchen behoben.
2024-03-02		2025-02-07e			Fehler in mehreren Übersetzungsdateien behoben.
2024-02-26		2025-02-07d			Bug behoben, welcher das Spiel abstürzen lässt (Fehlercode: 3221225477).
2024-02-25		2025-02-07c			Doppelte Keys aus Dateien entfernt.
2024-02-24		2025-02-07b			Alle Tabulatorzeichen nach den Keys entfernt.
2024-02-21		2025-02-07			Anpassungen an Version 2025-02-07
2024-12-22		2024-12-pre01		Anpassungen an Dezember Version
2024-15-10		0.9-pre4			Über 400 Fehler behoben
2024-13-10		0.9-pre3			Update auf Oktober Version
2024-09-10		0.9-pre2			Update auf September Version
2024-08-11		0.9-pre1			Komplette Neuübersetzung

Roadmap:

Diese Übersetzung ist komplett neu und wurde mit DeepL erstellt. Da DeepL aber alles übersetzt, incl. Variablen, Farbcodes, Icons, ...
werden noch massig Übersetzungsfehler vorhanden sein. Die werde ich im laufe der nächsten Montate noch ausbessern. Bei BlackICE hat es ca. 6 Monate gedauert.

Anmerkungen:
Sollten wieder erwarten nicht übersetzte Texte (z.B. GER_privatize_reichsbahn, GER_war_with_spain, ...) angezeigt werden kopierte den Inhalt meines mods in das Verzeichnis von RoadTo56.
.\SteamLibrary\steamapps\workshop\content\394360\2421485863\localisation nach .\SteamLibrary\steamapps\workshop\content\394360\820260968\localisation kopieren.