Übersetzung für die mod The Road to 56 (Version Oktober 2024)

Mein Dank geht an die tolle Arbeit der The Road to 56 Entwickler.
https://steamcommunity.com/sharedfiles/filedetails/?id=820260968&searchtext=road+to+56

History

2024-12-22		2024-12-pre01		Anpassungen an Dezember Version
2024-15-10		0.9-pre4			Über 400 Fehler behoben
2024-13-10		0.9-pre3			Update auf Oktober Version
2024-09-10		0.9-pre2			Update auf September Version
2024-08-11		0.9-pre1			Komplette Neuübersetzung

Roadmap:

Diese Übersetzung ist komplett neu und wurde mit DeepL erstellt. Da DeepL aber alles übersetzt, incl. Variablen, Farbcodes, Icons, ...
werden noch massig Übersetzungsfehler vorhanden sein. Die werde ich im laufe der nächsten Montate noch ausbessern. Bei BlackICE hat es ca. 6 Monate gedauert.