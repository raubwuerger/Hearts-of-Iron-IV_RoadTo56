version="2025-11-23"
tags={
	"Translation"
}
name="Road to 56 - German Edition"
supported_version="1.17.0"
remote_file_id="2421485863"