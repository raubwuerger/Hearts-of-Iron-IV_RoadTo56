version="2025-06-07a"
tags={
	"Translation"
}
name="Road to 56 - German Edition"
supported_version="1.16.*"
remote_file_id="2421485863"