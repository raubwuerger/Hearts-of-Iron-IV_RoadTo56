version="2025-02-07"
tags={
	"Translation"
}
name="Road to 56 - German Edition"
supported_version="1.15.*"
remote_file_id="2421485863"