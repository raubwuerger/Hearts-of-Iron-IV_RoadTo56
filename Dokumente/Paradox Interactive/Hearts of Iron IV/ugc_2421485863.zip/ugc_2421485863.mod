version="2025-04-13"
tags={
	"Translation"
}
name="Road to 56 - German Edition"
supported_version="1.16.*"
path="D:/Spiele/SteamLibrary/steamapps/workshop/content/394360/2421485863"
remote_file_id="2421485863"